var server = require('webserver').create();
var queryReg = /(?:\?|\&)(\w+)=([^\?\&]+)/g;

function startServer() {
	server.listen('127.0.0.1:9294', function(request, response) {
		var method = request.method;
		var url = request.url;
		if (method == 'GET') {
			var query = url.substr(url.indexOf('?'), url.length);
			var queryParam = {};
			while (true) {
				var result = queryReg.exec(query);
				if (result) {
					queryParam[result[1]] = result[2];
				} else {
					break;
				}
			}
			response.statusCode = 200;
			response.setEncoding('utf8');
			var clientId = queryParam['client_id'];
			var clientSecret = queryParam['client_secret'];
			var usercode = queryParam['usercode'];
			var password = queryParam['password'];
			var redirectUri = queryParam['redirect_uri'];
			if (clientId == undefined || clientId.length == 0) {
				var result = {
					"success" : false,
					msg : "client_id不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (clientSecret == undefined || clientSecret.length == 0) {
				var result = {
					"success" : false,
					msg : "clientSecret不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (usercode == undefined || usercode.length == 0) {
				var result = {
					"success" : false,
					msg : "usercode不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (password == undefined || password.length == 0) {
				var result = {
					"success" : false,
					msg : "password不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (redirectUri == undefined || redirectUri.length == 0) {
				var result = {
					"success" : false,
					msg : "redirect_uri不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			authorize(clientId, usercode, password, redirectUri, function(
					result) {
					response.write(result);
					response.close()
			});
		} else {
			response.statusCode = 200;
			response.setEncoding('utf8');
			var result = {
				"success" : false,
				msg : "不支持请求方式"
			};
			response.write(JSON.stringify(result));
			response.close();
		}
	});
	console.log('success');
}

function authorize(clientId, usercode, password, redirectUri, callback) {
	var page = require('webpage').create();
	page.clearCookies();
	var settings = {
		operation : "GET",
		encoding : "utf8"
	};
	var url = "https://api.twitter.com/oauth/authorize?oauth_token=" + clientId;
	page.open(url, settings);
	page.onLoadFinished = function(statu) {
		if (statu == 'success') {
			page.evaluate(function(usercode, password) {
				var userid = document.querySelector('#username_or_email');
				var passw = document.querySelector('#password');
				if (userid != null) {
					userid.value = usercode;
					passw.value = password;
					setTimeout(function() {
						document.querySelector('#allow').click();
					}, 500);
				}
			}, usercode, password);
		} else {
			callback(JSON.stringify({
				"url" : url,
				"msg" : "链接失败:" + statu,
				"code" : 5011
			}));
		}
	};
	page.onConsoleMessage = function(msg) {
		if (msg.indexOf("authorcode") != -1){
			callback(msg);
		}else if (msg.indexOf("Viewport argument value") = -1){
			callback(JSON.stringify({"msg": "登录失败:" + msg, "code": 502}));
		}
	};
	
	page.onUrlChanged = function(targetUrl) {
			page.evaluate(function() {
				setTimeout(function() {
					var body = document.getElementsByTagName('code');
					if (body.length > 0) {
						var code = body[0].innerHTML;
						console.log(JSON.stringify({"authorcode": code, "code": 200}));
					}
				}, 800);
			});
	};
}

startServer();
// authorize("2932213056", "wangzefu520@sohu.com", "wang19870916",
// "http://app.sobey.com/setup/pgcDown.jsp", function (result) {
// console.log(result);
// });

// token('89117ce2b0aa539b27553fdd7b6fd5b8','2932213056','0bba6b580c44fc94ef474ae2594f22be','http://app.sobey.com/setup/pgcDown.jsp',function(result){
// console.log(result);
// });
