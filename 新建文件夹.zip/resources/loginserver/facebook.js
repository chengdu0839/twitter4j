var server = require('webserver').create();
var queryReg = /(?:\?|\&)(\w+)=([^\?\&]+)/g;

function startServer() {
    server.listen('127.0.0.1:9993', function (request, response) {
        var method = request.method;
        var url = request.url;
        if (method == 'GET') {
            var query = url.substr(url.indexOf('?'), url.length);
            var queryParam = {};
            while (true) {
                var result = queryReg.exec(query);
                if (result) {
                    queryParam[result[1]] = result[2];
                } else {
                    break;
                }
            }
            response.statusCode = 200;
            response.setEncoding('utf8');
            var clientId = queryParam['client_id'];
            var clientSecret = queryParam['client_secret'];
            var usercode = queryParam['usercode'];
            var password = queryParam['password'];
            var redirectUri = queryParam['redirect_uri'];
            if (clientId == undefined || clientId.length == 0) {
                var result = {"success": false, msg: "client_id不能为空"};
                response.write(JSON.stringify(result));
                response.close();
                return;
            }
            if (clientSecret == undefined || clientSecret.length == 0) {
                var result = {"success": false, msg: "clientSecret不能为空"};
                response.write(JSON.stringify(result));
                response.close();
                return;
            }
            if (usercode == undefined || usercode.length == 0) {
                var result = {"success": false, msg: "usercode不能为空"};
                response.write(JSON.stringify(result));
                response.close();
                return;
            }
            if (password == undefined || password.length == 0) {
                var result = {"success": false, msg: "password不能为空"};
                response.write(JSON.stringify(result));
                response.close();
                return;
            }
            if (redirectUri == undefined || redirectUri.length == 0) {
                var result = {"success": false, msg: "redirect_uri不能为空"};
                response.write(JSON.stringify(result));
                response.close();
                return;
            }
            authorize(clientId, usercode, password, redirectUri, function (result) {
                var resultData = JSON.parse(result);
                if (resultData.code == 200) {
                    var authorCode = resultData.authorcode;
                    token(authorCode, clientId, clientSecret, redirectUri, function (tokenresult) {
                        response.write(tokenresult);
                        response.close();
                    });
                } else {
                    response.write(result);
                    response.close();
                }
            });
        } else {
            response.statusCode = 200;
            response.setEncoding('utf8');
            var result = {"success": false, msg: "不支持请求方式"};
            response.write(JSON.stringify(result));
            response.close();
        }
    });
    console.log('success');
}

function authorize(clientId, usercode, password, redirectUri, callback) {
    var page = require('webpage').create();
    page.clearCookies();
    var settings = {
        operation: "GET",
        encoding: "utf8"
    };
    var url = 'https://www.facebook.com/dialog/oauth?redirect_uri=' + redirectUri + '&client_id=' + clientId;
    page.open(url, settings);
    page.onLoadFinished=function(statu){
        if(statu == 'success') {
            page.evaluate(function (usercode, password) {
					var userid = document.getElementById('email');
					if (null != userid){
								var passwordel = document.getElementById('pass');
					userid.value = usercode;
					passwordel.value = password;
					setTimeout(function () {
						document.querySelector('#loginbutton').click();
					}, 1400);
					}
            }, usercode, password);
        }else{
            callback(JSON.stringify({"url": url, "msg": "链接失败:" + statu, "code": 501}));
        }
    };
    page.onConsoleMessage=function(msg){
        //callback(JSON.stringify({"msg": "登录失败:" + msg, "code": 502}));
    };
    page.onUrlChanged = function (targetUrl) {
        if (targetUrl.indexOf(redirectUri) != -1 && targetUrl.indexOf('code=') != -1) {
            var authorcode = targetUrl.substr(targetUrl.indexOf('code=') + 5);
            callback(JSON.stringify({"code": 200, "authorcode": authorcode}));
            page.close();
        }
    };
}

function token(authercode, clientId, clientSecret, redirectUri, callback) {
    var page = require('webpage').create();
	page.clearCookies();
    var settings = {
        operation: "GET",
        encoding: "utf8"
    };
    var url = "https:/graph.facebook.com/oauth/access_token?client_id=" + clientId + "&redirect_uri=" + redirectUri + "&client_secret=" + clientSecret + "&code=" + authercode;
    page.open(url, settings, function (statu) {
         if (statu != 'success') {
            callback(JSON.stringify({"url": url, "msg": "链接失败:" + statu, "code": 500}));
        } else {
            var json = JSON.parse(page.framePlainText);
            if(!!json['error']){
                callback(JSON.stringify({"url": url, "msg": "获取token失败:" + json['error_description'], "code": 500}));
            }else {
                callback(JSON.stringify({'tokendata': JSON.parse(page.framePlainText), "code": 200}));
            }
        }
        page.close();
    });
}


startServer();
// authorize("2932213056", "wangzefu520@sohu.com", "wang19870916", "http://app.sobey.com/setup/pgcDown.jsp", function (result) {
//     console.log(result);
// });

// token('89117ce2b0aa539b27553fdd7b6fd5b8','2932213056','0bba6b580c44fc94ef474ae2594f22be','http://app.sobey.com/setup/pgcDown.jsp',function(result){
//     console.log(result);
// });