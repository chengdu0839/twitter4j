var server = require('webserver').create();
var queryReg = /(?:\?|\&)(\w+)=([^\?\&]+)/g;

function startServer() {
	server.listen('127.0.0.1:9198', function(request, response) {
		var method = request.method;
		var url = request.url;
		if (method == 'GET') {
			var query = url.substr(url.indexOf('?'), url.length);
			var queryParam = {};
			while (true) {
				var result = queryReg.exec(query);
				if (result) {
					queryParam[result[1]] = result[2];
				} else {
					break;
				}
			}
			response.statusCode = 200;
			response.setEncoding('utf8');
			var clientId = queryParam['client_id'];
			var clientSecret = queryParam['client_secret'];
			var usercode = queryParam['usercode'];
			var password = queryParam['password'];
			var redirectUri = queryParam['redirect_uri'];
			if (clientId == undefined || clientId.length == 0) {
				var result = {
					"success" : false,
					msg : "client_id不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (clientSecret == undefined || clientSecret.length == 0) {
				var result = {
					"success" : false,
					msg : "clientSecret不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (usercode == undefined || usercode.length == 0) {
				var result = {
					"success" : false,
					msg : "usercode不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (password == undefined || password.length == 0) {
				var result = {
					"success" : false,
					msg : "password不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			if (redirectUri == undefined || redirectUri.length == 0) {
				var result = {
					"success" : false,
					msg : "redirect_uri不能为空"
				};
				response.write(JSON.stringify(result));
				response.close();
				return;
			}
			authorize(clientId, usercode, password, redirectUri, function(
					result) {
					response.write(result);
					response.close()
			});
		} else {
			response.statusCode = 200;
			response.setEncoding('utf8');
			var result = {
				"success" : false,
				msg : "不支持请求方式"
			};
			response.write(JSON.stringify(result));
			response.close();
		}
	});
	console.log('success');
}

function authorize(clientId, usercode, password, redirectUri, callback) {
	var page = require('webpage').create();
	page.clearCookies();
	var settings = {
		operation : "GET",
		encoding : "utf8"
	};
	var url = "https://accounts.google.com/o/oauth2/auth?redirect_uri="
			+ redirectUri
			+ "&client_id="
			+ clientId
			+ "&response_type=code&scope=https://www.googleapis.com/auth/youtube";
	page.open(url, settings);
	page.onLoadFinished = function(statu) {
		if (statu == 'success') {
			page.evaluate(function(usercode, password) {
				var userid = document.querySelector('#Email');
				if (userid != null) {
					userid.value = usercode;
					setTimeout(function() {
						document.querySelector('#next').click();
					}, 800);
				}
			}, usercode, password);
		} else {
			callback(JSON.stringify({
				"url" : url,
				"msg" : "链接失败:" + statu,
				"code" : 5011
			}));
		}
	};
	page.onConsoleMessage = function(msg) {
		console.log(msg);
	    //callback(JSON.stringify({"msg": "登录失败:" + msg, "code": 502}));
	};
	page.onUrlChanged = function(targetUrl) {
		if (targetUrl.indexOf(redirectUri) != -1
				&& targetUrl.indexOf('code=') != -1) {
			var authorcode = targetUrl.substr(targetUrl.indexOf('code=') + 5);
			callback(JSON.stringify({
				"code" : 200,
				"authorcode" : authorcode
			}));
			page.close();
		} else if (targetUrl.indexOf("password") != -1) {
			page.evaluate(function(password) {
				setTimeout(function() {
					var pass = document.querySelector('#Passwd');
					if (pass.value != password) {
						pass.value = password;
						document.querySelector('#next').click();
					}
				}, 2000);
			}, password);

		} else if (targetUrl.indexOf("pageId=none") != -1) {
			page.evaluate(function() {
				setTimeout(function() {
					document.querySelector('#submit_approve_access').click();
				}, 2000);
			});
		}
	};
}

startServer();
// authorize("2932213056", "wangzefu520@sohu.com", "wang19870916",
// "http://app.sobey.com/setup/pgcDown.jsp", function (result) {
// console.log(result);
// });

// token('89117ce2b0aa539b27553fdd7b6fd5b8','2932213056','0bba6b580c44fc94ef474ae2594f22be','http://app.sobey.com/setup/pgcDown.jsp',function(result){
// console.log(result);
// });
