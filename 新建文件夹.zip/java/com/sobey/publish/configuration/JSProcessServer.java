package com.sobey.publish.configuration;

import java.net.InetAddress;
import java.net.ServerSocket;

import javax.net.ServerSocketFactory;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class JSProcessServer {

	private static Logger LOGGER = Logger.getLogger(JSProcessServer.class);

	@Async("overseaExecutor")
	public void processFacebookServer(String jsServerPath) {
		try {
			LOGGER.info("启动facebook认证服务命令为:");
			int port = 9993;
			boolean validSocket = validSocket(port);
			if (validSocket) {
				Runtime runtime = Runtime.getRuntime();
				String path = jsServerPath;
				String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/facebook.js";
				LOGGER.info("启动facebook认证服务命令为:" + cmd);
				Process loginServerProcess = runtime.exec(cmd);
				int statu = loginServerProcess.waitFor();
				LOGGER.info("退出值为:" + statu);
			} else {
				LOGGER.info("port = " + port + ", facebook端口已打开");
			}
		} catch (Exception e) {
			LOGGER.error("启动facebook认证服务异常:", e);
		}
	}

	@Async("overseaExecutor")
	public void processYoutubeServer(String jsServerPath) {
		try {
			int port = 9198;
			boolean validSocket = validSocket(port);
			if (validSocket) {
				Runtime runtime = Runtime.getRuntime();
				String path = jsServerPath;
				String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/youtube.js";
				LOGGER.info("启动youtube认证服务命令为:" + cmd);
				Process loginServerProcess = runtime.exec(cmd);
				int statu = loginServerProcess.waitFor();
				LOGGER.info("退出值为:" + statu);
			} else {
				LOGGER.info("port = " + port + ", youtube端口已打开");
			}
		} catch (Exception e) {
			LOGGER.error("启动youtube认证服务异常:", e);
		}
	}

	@Async("overseaExecutor")
	public void processTwitterServer(String jsServerPath) {
		try {
			int port = 9294;
			boolean validSocket = validSocket(port);
			if (validSocket) {
				Runtime runtime = Runtime.getRuntime();
				String path = jsServerPath;
				String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/twitter.js";
				LOGGER.info("启动twitter认证服务命令为:" + cmd);
				Process loginServerProcess = runtime.exec(cmd);
				int statu = loginServerProcess.waitFor();
				LOGGER.info("退出值为:" + statu);
			} else {
				LOGGER.info("port = " + port + ", twitter端口已打开");
			}
		} catch (Exception e) {
			LOGGER.error("启动twitter认证服务异常:", e);
		}
	}

	public boolean validSocket(int port) {
		try {
			ServerSocket serverSocket = ServerSocketFactory.getDefault().createServerSocket(port, 1,
					InetAddress.getByName("localhost"));
			serverSocket.close();
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
}