package com.sobey.publish.configuration;

import javax.jms.ConnectionFactory;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.util.backoff.ExponentialBackOff;

import com.sobey.publish.config.MQConfig;

/**
 * BackOff退避算法<br>
 * FixedBackOff：按照固定时间间隔重试，比如100毫秒；这种方式在网络不稳定时重连可能造成某一时间点流量同时发送，阻塞网络；
 * 或者造成发送一些无意义的请求；<br>
 * ExponentialBackOff：按照指数时间间隔重试，比如刚开始100毫秒，下一次200毫秒等；比如支付宝和第三方集成时就是类似方式。
 * 
 * <br>
 * <br>
 * DefaultMessageListenerContainer是一个用于异步消息监听的管理类。
 * 
 * @author zw
 *
 */
@Configuration
public class MessagingListnerConfiguration {
	@Autowired
	private MQConfig mqConfig;

	@Bean(name = { "defaultJmsListenerContainerFactory" })
	public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(cachingConnectionFactory());
		factory.setConcurrency("1-1");
		// 设置MQ重试机制。默认使用该机制。
		// BackOff backOff = new FixedBackOff(10000, Long.MAX_VALUE);
		// factory.setBackOff(backOff);
		int initialInterval = 500;// 初始重试间隔
		int maxInterval = 60 * 1000;// 最大的重试间隔
		int maxElapsedTime = 600 * 1000;// 重试的最大时长。超过该时间，则停止重试。
		double multiplier = 1.5;// 递增倍数（即下次间隔是上次的多少倍）
		ExponentialBackOff exponentBackOff = new ExponentialBackOff(initialInterval, multiplier);
		exponentBackOff.setMaxInterval(maxInterval);
		exponentBackOff.setMaxElapsedTime(maxElapsedTime);
		factory.setBackOff(exponentBackOff);
		return factory;
	}

	public ConnectionFactory cachingConnectionFactory() {
		ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
		activeMQConnectionFactory.setBrokerURL(mqConfig.getBrokerurl());
		activeMQConnectionFactory.setUserName(mqConfig.getUsername());
		activeMQConnectionFactory.setSendTimeout(3000);
		activeMQConnectionFactory.setPassword(mqConfig.getPassword());
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
		connectionFactory.setTargetConnectionFactory(activeMQConnectionFactory);
		connectionFactory.setSessionCacheSize(100);   
		return connectionFactory;
	}

	@Bean
	public JmsMessagingTemplate jmsMessagingTemplate() {
		JmsMessagingTemplate template = new JmsMessagingTemplate();
		template.setConnectionFactory(cachingConnectionFactory());
		return template;
	}

}