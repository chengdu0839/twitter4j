package com.sobey.publish.configuration;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sobey.publish.common.TokenService;
import com.sobey.publish.facebook.Facebook;

public class StartupRunner2 implements CommandLineRunner {

	private static Logger LOGGER = Logger.getLogger(Facebook.class);

	@Autowired
	private JSProcessServer jSProcessServer;

	@Autowired
	private TokenService tokenService;
	
	@Override
	public void run(String... args) throws Exception {
		Process exec = Runtime.getRuntime().exec("taskkill /IM phantomjs.exe /f /t");
		exec.waitFor();
		URL resource = this.getClass().getResource("/");
		String jsServerPath = resource.getPath().substring(1);
		/*jSProcessServer.processFacebookServer(jsServerPath);
		jSProcessServer.processYoutubeServer(jsServerPath);
		jSProcessServer.processTwitterServer(jsServerPath);*/
		Thread.sleep(8000);
		System.out.println(tokenService);
	}

	@Async
	public void test() throws Exception {
		// 创建系统进程
		ProcessBuilder pb = new ProcessBuilder("tasklist");
		Process p = pb.start();
		BufferedReader out = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(p.getInputStream()), Charset.forName("GB2312")));
		BufferedReader err = new BufferedReader(new InputStreamReader(new BufferedInputStream(p.getErrorStream())));
		System.out.println("Window 系统进程列表");
		String ostr;
		while ((ostr = out.readLine()) != null)
			System.out.println(ostr);
		String estr = err.readLine();
		if (estr != null) {
			System.out.println("\nError Info");
			System.out.println(estr);
		}
	}

	@Async
	private void processFacebookServer() {
		try {
			Runtime runtime = Runtime.getRuntime();
			String path = "";
			String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/facebook.js";
			LOGGER.info("启动facebook认证服务命令为:" + cmd);
			Process loginServerProcess = runtime.exec(cmd);
			int statu = loginServerProcess.waitFor();
			LOGGER.info("退出值为:" + statu);
		} catch (Exception e) {
			LOGGER.error("启动facebook认证服务异常:", e);
		}
	}

	@Async
	private void processYoutubeServer() {
		try {
			Runtime runtime = Runtime.getRuntime();
			String path = "";
			String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/youtube.js";
			LOGGER.info("启动youtube认证服务命令为:" + cmd);
			Process loginServerProcess = runtime.exec(cmd);
			int statu = loginServerProcess.waitFor();
			LOGGER.info("退出值为:" + statu);
		} catch (Exception e) {
			LOGGER.error("启动youtube认证服务异常:", e);
		}
	}

	@Async
	private void processTwitterServer() {
		try {
			Runtime runtime = Runtime.getRuntime();
			String path = "";
			String cmd = path + "loginserver/phantomjs.exe " + path + "/loginserver/twitter.js";
			LOGGER.info("启动twitter认证服务命令为:" + cmd);
			Process loginServerProcess = runtime.exec(cmd);
			int statu = loginServerProcess.waitFor();
			LOGGER.info("退出值为:" + statu);
		} catch (Exception e) {
			LOGGER.error("启动twitter认证服务异常:", e);
		}
	}
}