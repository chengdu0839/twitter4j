package com.sobey.publish.configuration;

import java.net.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.sobey.publish.common.TokenService;

@Component
@Order(value = 1)
public class StartupRunner implements CommandLineRunner {

	@Autowired
	private JSProcessServer jSProcessServer;

	@Autowired
	private TokenService tokenService;

	@Override
	public void run(String... args) throws Exception {
		URL resource = this.getClass().getResource("/");
		String jsServerPath = resource.getPath().substring(1);
		jSProcessServer.processFacebookServer(jsServerPath);
		jSProcessServer.processYoutubeServer(jsServerPath);
		jSProcessServer.processTwitterServer(jsServerPath);
		tokenService.initTokenRunner();
	}
}