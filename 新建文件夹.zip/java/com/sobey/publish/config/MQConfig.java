package com.sobey.publish.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="mq")
public class MQConfig {
    /**
     * MQ地址
     */
	@Value("${mq.url:tcp://localhost:61616}")
    private String brokerurl;
	
	@Value("${mq.username:}")
	private String username;
	
	@Value("${mq.password:}")
	private String password;

	public String getBrokerurl() {
		return brokerurl;
	}

	public void setBrokerurl(String brokerurl) {
		this.brokerurl = brokerurl;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
