package com.sobey.publish.oversea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OverseaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OverseaApplication.class, args);
	}
}
