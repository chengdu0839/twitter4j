package com.sobey.publish.facebook;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

/*
 * 利用HttpClient进行post请求的工具类
 */
public class FacebookClientUtil {
	private static Logger logger = Logger.getLogger(FacebookClientUtil.class);
	/**
	 * post传list参数
	 */
	public static String doPost(String url, List<NameValuePair> list, String charset) {
		HttpClient httpClient = null;
		HttpPost httpPost = null;
		String result = null;
		try {
			httpClient = new SSLClient();
			httpPost = new HttpPost(url);
			if (list.size() > 0) {
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list, charset);
				httpPost.setEntity(entity);
			}
			HttpResponse response = httpClient.execute(httpPost);
			if (response != null) {
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					result = EntityUtils.toString(resEntity, charset);
					logger.info("doPost method, result:" + result);
				}
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
		}
		return result;
	}

	@SuppressWarnings("deprecation")
	public static String uploadfile(String url, File file, String content, String token, boolean publish) {
		logger.info("url:" + url + "filename:" + file.getName() + "content:" + content + "token:" + token);
		String result = "";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			HttpPost httppost = new HttpPost(url);
			FileBody filebody = new FileBody(file);
			StringBody caption = new StringBody(content, Charset.forName("UTF-8"));
			StringBody published = new StringBody(String.valueOf(publish), Charset.forName("UTF-8"));
			StringBody access_token = new StringBody(token, Charset.forName("UTF-8"));
			HttpEntity reqEntity = MultipartEntityBuilder.create().addPart("file", filebody).addPart("caption", caption)
					.addPart("published", published).addPart("access_token", access_token).build();

			httppost.setEntity(reqEntity);
			CloseableHttpResponse response = httpclient.execute(httppost);
			try {
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					result = EntityUtils.toString(resEntity, "UTF-8");
					logger.info("uploadfile method, result:" + result);
				}
				EntityUtils.consume(resEntity);
			} finally {
				response.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
