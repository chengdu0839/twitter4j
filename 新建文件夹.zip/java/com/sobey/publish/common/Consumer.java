package com.sobey.publish.common;

import java.io.File;
import java.util.Map;

import javax.jms.Destination;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sobey.publish.util.PluginExtendUtils;

@Component
public class Consumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(Consumer.class);

	@Value("${back.destination}")
	private String backDestination;

	@Value("${ftp.path}")
	private String ftpPath;

	@Autowired
	private Producer producer;

	// 使用JmsListener配置消费者监听的队列，其中text是接收到的消息
	@JmsListener(destination = "${queue.destination}", containerFactory = "defaultJmsListenerContainerFactory")
	public void receiveQueue(String text) {
		LOGGER.info("接收到的MQ内容为:" + text);
		JSONObject inputObj = JSON.parseObject(text);
		PublishTaskVo vo = parser(inputObj);
	    System.out.println(text);
		String channelcode = inputObj.getString("channelcode");
		IPublishService publishService = PluginExtendUtils.getIPublishService(channelcode);
		JSONObject param = new JSONObject();
		try {
			boolean publish = publishService.publish(vo);
			param.put("taskid", inputObj.getString("taskid"));
			param.put("status", publish);
			param.put("message", "");
		} catch (Exception e) {
			param.put("taskid", inputObj.getString("taskid"));
			param.put("status", false);
			param.put("message", e.getMessage());
		}
		LOGGER.info("MQ反馈信息： " + param.toString());
		Destination destination = new ActiveMQQueue(backDestination);
		producer.sendMessage(destination, param.toString());
	}

	private PublishTaskVo parser(JSONObject inputObj) {
		JSONObject accountsObject = inputObj.getJSONObject("accounts");
		String username = accountsObject.getString("username");
		String password = accountsObject.getString("password");
		JSONObject contentObject = inputObj.getJSONObject("content");
		PublishTaskVo taskVo = new PublishTaskVo();
		String content = contentObject.getString("content");
		String pathDir = inputObj.getString("path");
		String title = contentObject.getString("title");
		String keyword = contentObject.getString("keyword");
		taskVo.setUsername(username);
		taskVo.setPassword(password);
		taskVo.setTitle(title);
		taskVo.setContent(content);
		taskVo.setKeyword(keyword);
		String videoUrl = contentObject.getString("videoUrl");
		if (StringUtils.isNotEmpty(videoUrl)) {
			videoUrl = ftpPath + pathDir + videoUrl.substring(videoUrl.lastIndexOf("/") + 1);
			File videoFile = new File(videoUrl);
			if (videoFile.exists()) {
				taskVo.setVideoFile(videoFile);
			}
		}
		JSONArray imageArray = contentObject.getJSONArray("images");
		if (null != imageArray && !imageArray.isEmpty()) {
			for (int i = 0; i < imageArray.size(); i++) {
				String imageUrl = (String) ((Map<?, ?>) imageArray.get(i)).get("image");
				String imagePath = ftpPath + pathDir + imageUrl.substring(imageUrl.lastIndexOf("/") + 1);
				File imageFile = new File(imagePath);
				if (imageFile.exists()) {
					taskVo.getImageFileList().add(imageFile);
				}
			}
		}
		return taskVo;
	}
}
