package com.sobey.publish.common;

/**
 * 发布接口
 */
public interface IPublishService {

	public boolean publish(PublishTaskVo vo) throws Exception;
	
	public String getPublishType();
	
	public TokenInfo getToken(String username, String password);
}
