package com.sobey.publish.common;

import java.util.concurrent.DelayQueue;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.sobey.publish.util.PluginExtendUtils;

@Component
public final class TokenSingleton2 {
	private static Logger LOGGER = Logger.getLogger(TokenSingleton2.class);
	/**
	 * 账号信息缓存
	 */
	private static DelayQueue<TokenInfo> delayQueue = new DelayQueue<TokenInfo>();
	/**
	 * 后台线程
	 */
	private static Thread thread;

	private TokenSingleton2() {
	}

	public final static TokenSingleton2 getInstance() {
		return InstanceHolder.instance;
	}

	public void putQueue(TokenInfo info) {
		delayQueue.put(info);
	}

	public TokenInfo getToken(String type, String username, String password) {
		TokenInfo[] arrayInfos = delayQueue.toArray(new TokenInfo[] {});
		if (null != arrayInfos) {
			for (TokenInfo info : arrayInfos) {
				if (username.equals(info.getUsername()) && password.equals(info.getPassword())
						&& type.equals(info.getType())) {
					return info;
				}
			}
		}
		return null;
	}

	public void init(String username, String password) {
		LOGGER.info("初始化facebook延迟队列...");
		delayQueue = new DelayQueue<TokenInfo>();
		thread = new Thread(new DelayRunner(delayQueue));
		thread.setName("Token Runner");
		thread.setDaemon(true);
		thread.start();
	}

	static class InstanceHolder {
		static TokenSingleton2 instance = new TokenSingleton2();
	}

	class DelayRunner implements Runnable {
		private DelayQueue<TokenInfo> delayQueue;

		public DelayRunner(DelayQueue<TokenInfo> delayQueue) {
			super();
			this.delayQueue = delayQueue;
		}

		@Override
		public void run() {
			while (true) {
				try {
					TokenInfo info = delayQueue.take();
					LOGGER.info("Runner获取token" + info.toString());
					IPublishService service = PluginExtendUtils.getIPublishService(info.getType());
					TokenInfo tokenInfo = service.getToken(info.getUsername(), info.getPassword());
					if (null != tokenInfo) {
						delayQueue.put(tokenInfo);
					}
				} catch (InterruptedException e) {
					LOGGER.error("Runner获取缓存数据失败", e);
				}
			}
		}

	}
}
