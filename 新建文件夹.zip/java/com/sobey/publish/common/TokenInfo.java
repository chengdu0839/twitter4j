package com.sobey.publish.common;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.digest.DigestUtils;

public class TokenInfo implements Delayed{
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	private String password;
	/**
	 * token值
	 */
	private String token;
	/**
	 * 过期时间单位为纳秒
	 */
	private long expireTime;
	
	private String type;
	
	

	public TokenInfo(String username, String password,
			String token, String type, long expireTime) {
		this.username = username;
		this.password = password;
		this.token = token;
		this.expireTime = TimeUnit.NANOSECONDS.convert(expireTime - 30, TimeUnit.SECONDS) + System.nanoTime();
	}

	public TokenInfo(String token, int expireTime) {
		this.token = token;
		this.expireTime = TimeUnit.NANOSECONDS.convert(expireTime - 30, TimeUnit.SECONDS) + System.nanoTime();
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getToken() {
		return token;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public int compareTo(Delayed delayed) {
		if(null == delayed||!(delayed instanceof TokenInfo))
			return 1;
		if(delayed == this) return 0;
		TokenInfo sinaWeiboInfo = (TokenInfo) delayed;
		if(this.expireTime>sinaWeiboInfo.expireTime)
			return 1;
		else if(this.expireTime==sinaWeiboInfo.expireTime)
			return 0;
		else
			return -1;
	}

	@Override
	public long getDelay(TimeUnit timeUnit) {
		return timeUnit.convert(this.expireTime - System.nanoTime(), TimeUnit.NANOSECONDS);
	}
	/**
	 * 获取值
	 * @return
	 */
	public String getKey(){
		return DigestUtils.md5Hex(type + username + password);
	}

	@Override
	public String toString() {
		return "TokenInfo [username=" + username + ", password=" + password + ", token=" + token + ", expireTime="
				+ expireTime + ", type=" + type + "]";
	}
}
