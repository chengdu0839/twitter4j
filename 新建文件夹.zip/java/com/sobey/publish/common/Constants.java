package com.sobey.publish.common;

public final class Constants {

	public static final String BASE_API_URL = "https://ads-api.twitter.com/";
	public static final String TWITTER_UPLOAD = "https://upload.twitter.com";
	public static final String SANDBOX_BASE_API_URL = "https://ads-api-sandbox.twitter.com/";
	public static final String FACEBOOK = "facebook";
	public static final String YOUTUBE = "youtube";
	public static final String TWITTER = "twitter";

}
