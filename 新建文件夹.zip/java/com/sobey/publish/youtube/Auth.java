package com.sobey.publish.youtube;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.StoredCredential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleOAuthConstants;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.sobey.publish.util.HttpClientUtil;

/**
 * Shared class used by every sample. Contains methods for authorizing a user
 * and caching credentials.
 */
@Component
public class Auth {
	private static Logger logger = Logger.getLogger(Auth.class);
	@Value("${youtube.clientId}")
	private String clientId;
	@Value("${youtube.clientSecret}")
	private String clientSecret;
	@Value("${youtube.redirectUri}")
	private String redirectUri;
	/**
	 * Define a global instance of the HTTP transport.
	 */
	public static final HttpTransport HTTP_TRANSPORT = new NetHttpTransport();

	/**
	 * Define a global instance of the JSON factory.
	 */
	public static final JsonFactory JSON_FACTORY = new JacksonFactory();

	/**
	 * Authorizes the installed application to access user's protected data.
	 *
	 * @param scopes
	 *            list of scopes needed to run youtube upload.
	 * @param credentialDatastore
	 *            name of the credential datastore to cache OAuth tokens
	 */
	public Credential authorize(String username, String password) throws IOException {
		String url = "http://localhost:9198/getToken?redirect_uri=" + redirectUri + "&client_id=" + clientId
				+ "&client_secret=" + clientSecret + "&usercode=" + username + "&password=" + password;
		logger.info("youtube auth url = " + url);
		URL resource = Auth.class.getResource("/");
		String path = resource.getPath().substring(1);
		FileDataStoreFactory fileDataStoreFactory = new FileDataStoreFactory(
				new File(path + "config" + File.separator + ".oauth-credentials"));
		DataStore<StoredCredential> datastore = fileDataStoreFactory.getDataStore("uploadvideo");
		AuthorizationCodeFlow build = new AuthorizationCodeFlow.Builder(BearerToken.authorizationHeaderAccessMethod(),
				HTTP_TRANSPORT, JSON_FACTORY, new GenericUrl(GoogleOAuthConstants.TOKEN_SERVER_URL),
				new ClientParametersAuthentication(clientId, clientSecret), clientId,
				GoogleOAuthConstants.AUTHORIZATION_SERVER_URL).setCredentialDataStore(datastore).build();
		TokenResponse tokenResponse = null;
		StoredCredential storedCredential = datastore.get("uploadvideo");
		if (null != storedCredential) {
			if (storedCredential.getExpirationTimeMilliseconds() != null) {
				Date date = new Date(storedCredential.getExpirationTimeMilliseconds() - 50000);
				if (date.compareTo(new Date()) > 0) {
					return build.loadCredential("uploadvideo");
				}
			}
		}
		logger.info("获取用户code URL：" + url);
		String code = HttpClientUtil.getInstance().get(url);
		logger.info("获取用户code返回值:" + code);
		JSONObject jsonObject = JSON.parseObject(code);
		if (jsonObject.containsKey("code") && jsonObject.containsKey("authorcode")
				&& jsonObject.getString("code").equals("200")) {
			String authorcode = jsonObject.getString("authorcode");
			tokenResponse = build.newTokenRequest(authorcode).setRedirectUri(redirectUri).execute();
			Credential createAndStoreCredential = build.createAndStoreCredential(tokenResponse, "uploadvideo");
			return createAndStoreCredential;
		}
		throw new RuntimeException(code);
	}
}
