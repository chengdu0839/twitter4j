package com.sobey.publish.twitter.client;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public interface ClientService {
	public WebResource getResource();
	public Client getClient();
	public void setDomain(String domain);
}
