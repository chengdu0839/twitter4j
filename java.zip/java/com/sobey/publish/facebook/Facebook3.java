package com.sobey.publish.facebook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.restfb.BinaryAttachment;
import com.restfb.Connection;
import com.restfb.FacebookClient;
import com.restfb.FacebookClient.AccessToken;
import com.restfb.Parameter;
import com.restfb.types.Account;
import com.restfb.types.FacebookType;
import com.restfb.types.GraphResponse;
import com.restfb.types.ResumableUploadStartResponse;
import com.restfb.types.ResumableUploadTransferResponse;
import com.sobey.publish.common.Constants;
import com.sobey.publish.common.IPublishService;
import com.sobey.publish.common.PublishTaskVo;
import com.sobey.publish.common.TokenInfo;
import com.sobey.publish.common.TokenService;
import com.sobey.publish.util.HttpClientUtil;
import com.restfb.DefaultFacebookClient;
import com.restfb.Version;
import com.restfb.exception.FacebookOAuthException;

/**
 * facebook发布实现类
 * 
 * @author sunzb
 * 
 */
public class Facebook3 implements IPublishService {
	private static Logger LOGGER = Logger.getLogger(Facebook3.class);
	private FacebookClient facebookClient;
	private String accessToken = null;
	private String graphUrl = "https://graph.facebook.com/v2.11/";
	private String accountId = "me";
	@Value("${facebook.clientId}")
	private String clientId;
	@Value("${facebook.clientSecret}")
	private String clientSecret;
	@Value("${facebook.redirectUri}")
	private String redirectUri;
	private static long day = TimeUnit.MILLISECONDS.convert(2, TimeUnit.DAYS);

	@Autowired
	private TokenService tokenService;
	
	public void init(String username, String password) {
		try {
			username = "8860975141599";
			password = "sun0522";
			TokenInfo tokenInfo = null;
			if (null == tokenInfo) {
				tokenInfo = getToken(username, password);
				if (tokenInfo != null) {
					tokenInfo.setType(Constants.FACEBOOK);
					//tokenService.putQueue(tokenInfo);
				}
			}
			if (null != tokenInfo) {
				accessToken = tokenInfo.getToken();
				this.facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_11);
				Connection<Account> fetchConnection = facebookClient.fetchConnection(accountId + "/accounts",
						Account.class);
				List<Account> accounts = fetchConnection.getData();
				if (!accounts.isEmpty()) {
					for (Account account : accounts) {
						if ("Sobeycctv".equals(account.getName())) {
							accessToken = account.getAccessToken();
							accountId = account.getId();
							this.facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_11);
							LOGGER.info("facebook公共主页发布: name = " + account.getName() + ", id = " + accountId);
						}
					}
					Account account = accounts.get(0);
				} else {
					LOGGER.info("facebook个人主页发布");
				}
			} else {
				throw new RuntimeException("获取facebook的token异常。");
			}
		} catch (FacebookOAuthException e) {
			throw new RuntimeException(e.getErrorMessage());
		}
	}

	public AccessToken obtainExtendedAccessToken(String token) {
		return facebookClient.obtainExtendedAccessToken(clientId, clientSecret, token);
	}

	public TokenInfo getToken(String username, String password) {
		redirectUri = "http://app.sobey.com/setup/pgcDown.jsp";
		clientId = "1014784071995322";
		clientSecret = "31c3b7c71ad6090eed6413985a97dbb0";
		String url = "http://localhost:9993/getToken?redirect_uri=" + redirectUri + "&client_id=" + clientId
				+ "&client_secret=" + clientSecret + "&usercode=" + username + "&password=" + password;
		LOGGER.info("获取Facebook的url地址为: " + url);
		String result = HttpClientUtil.getInstance().get(url);
		LOGGER.info("facebook result = " + result);
		JSONObject jsonObject = JSON.parseObject(result);
		boolean resultStatu = checkResultStatu(jsonObject);
		if (!resultStatu) {
			result = HttpClientUtil.getInstance().get(url);
			LOGGER.info("facebook result = " + result);
			jsonObject = JSON.parseObject(result);
			resultStatu = checkResultStatu(jsonObject);
			if (!resultStatu) {
				throw new RuntimeException("Facebook账号，获取异常! " + result);
			}
		}
		String authorcode = jsonObject.getString("tokendata");
		JSONObject authorcodeObject = JSON.parseObject(authorcode);
		if (authorcodeObject.containsKey("access_token")) {
			String token = authorcodeObject.getString("access_token");
			this.facebookClient = new DefaultFacebookClient(token, Version.VERSION_2_6);
			AccessToken extendedAccessToken = obtainExtendedAccessToken(token);
			accessToken = extendedAccessToken.getAccessToken();
			Date expires = extendedAccessToken.getExpires();
			long expireTime = 5167627;
			if (null != expires) {
				expireTime = TimeUnit.SECONDS.convert((expires.getTime() - new Date().getTime() - day),
						TimeUnit.MILLISECONDS);
			}
			TokenInfo tokenInfo = new TokenInfo(username, password, extendedAccessToken.getAccessToken(),
					Constants.FACEBOOK, expireTime);
			return tokenInfo;
		}
		throw new RuntimeException("Facebook账号，获取异常! " + result);
	}

	/**
	 * 验证返回结果
	 * 
	 * @param result
	 * @return
	 */
	private boolean checkResultStatu(JSONObject jsonObject) {
		return jsonObject != null && jsonObject.containsKey("code") && jsonObject.containsKey("tokendata")
				&& jsonObject.getString("code").equals("200");
	}

	/**
	 * 发布文字信息
	 * 
	 * @param message
	 * @return
	 */
	public String publishMessage(String message) throws Exception {
		if (null == facebookClient) {
			LOGGER.error("FaceBook类没有初始化！");
			throw new Exception("FaceBook类没有初始化！");
		}
		LOGGER.info("发布facebook纯文字信息");
		GraphResponse publishMessageResponse = facebookClient.publish(accountId + "/feed", GraphResponse.class,
				Parameter.with("message", message), Parameter.with("published", "true"));
		return publishMessageResponse.getId();
	}
	
	public String updateMessage(String id, String message) throws Exception {
		if (null == facebookClient) {
			LOGGER.error("FaceBook类没有初始化！");
			throw new Exception("FaceBook类没有初始化！");
		}
		LOGGER.info("更新facebook文字信息: id = " + id + ", message = " + message);
		GraphResponse publishMessageResponse = facebookClient.publish(id, GraphResponse.class,
				Parameter.with("message", message));
		return publishMessageResponse.getId();
	}

	/**
	 * 发布单图信息
	 * 
	 * @param message
	 * @param inputStream
	 * @param fileName
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public String publishPhoto(String message, File file) throws Exception {
		LOGGER.info("发布facebook图文信息");
		FacebookType publishPhotoResponse = facebookClient.publish(accountId + "/photos", FacebookType.class,
				BinaryAttachment.with(file.getName(), new FileInputStream(file)), Parameter.with("message", message));
		return publishPhotoResponse.getId();
	}

	/**
	 * 发布多图片信息。
	 * 
	 * @param message
	 * @param inputStream
	 * @param fileName
	 * @return
	 */
	public String publishPhotos(String message, List<File> files) throws Exception {
		List<String> ids = new ArrayList<String>();
		for (File file : files) {
			String result = FacebookClientUtil.uploadfile(graphUrl + accountId + "/photos", file, message,
					this.accessToken, false);
			ids.add(JSON.parseObject(result).getString("id"));
			LOGGER.info("file = " + file.getAbsolutePath() + ", id = " + result);
		}
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		list.add(new BasicNameValuePair("message", message));
		list.add(new BasicNameValuePair("access_token", this.accessToken));
		for (int i = 0; i < ids.size(); i++) {
			list.add(new BasicNameValuePair("attached_media[" + i + "]", "{\"media_fbid\":\"" + ids.get(i) + "\"}"));
		}
		return FacebookClientUtil.doPost(graphUrl + accountId + "/feed", list, "UTF-8");
	}
	
	public String publishPhotos2(String message, List<File> files) throws Exception {
		List<String> ids = new ArrayList<String>();
		for (File file : files) {
			String result = FacebookClientUtil.uploadfile(graphUrl + accountId + "/videos", file, message,
					this.accessToken, false);
			ids.add(JSON.parseObject(result).getString("id"));
			LOGGER.info("file = " + file.getAbsolutePath() + ", id = " + result);
		}
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		list.add(new BasicNameValuePair("message", message));
		list.add(new BasicNameValuePair("access_token", this.accessToken));
		for (int i = 0; i < ids.size(); i++) {
			list.add(new BasicNameValuePair("attached_media[" + i + "]", "{\"media_fbid\":\"" + ids.get(i) + "\"}"));
		}
		return FacebookClientUtil.doPost(graphUrl + accountId + "/feed", list, "UTF-8");
	}

	/**
	 * 发布视频
	 * 
	 * @param videoFile
	 * @param content
	 */
	public String uploadVideo(File videoFile, String content) {
		LOGGER.info("发布facebook视频信息");
		ResumableUploadStartResponse returnValue = initVideo(videoFile);
		if (null != returnValue) {
			LOGGER.info("初始化视频上传数据：upload_session_id = " + returnValue.getUploadSessionId() + "videoFile = "
					+ videoFile.getAbsolutePath() + "videoId = " + returnValue.getVideoId());
			appendVideo(returnValue, videoFile);
			return finalizeVideo(returnValue.getUploadSessionId(), content);
		}
		LOGGER.error("facebook视频发布初始化失败. ");
		return null;
	}

	private void appendVideo(ResumableUploadStartResponse returnValue, File videoFile) {
		FileInputStream in = null;
		long startOffset = returnValue.getStartOffset();
		long endOffset = returnValue.getEndOffset();
		String uploadSessionId = returnValue.getUploadSessionId();
		int index = 1;
		try {
			int length = (int) (endOffset - startOffset);
			in = new FileInputStream(videoFile);
			// We have to upload the chunks in a loop
			while (length > 0) {
				// First copy bytes in byte array
				byte fileBytes[] = new byte[length];
				in.read(fileBytes);
				// Make the request to Facebook
				ResumableUploadTransferResponse filePart = facebookClient.publish(accountId + "/videos",
						// The returned object
						ResumableUploadTransferResponse.class,
						// The file chunk that should be uploaded now
						BinaryAttachment.with("video_file_chunk", fileBytes),
						// Tell Facebook that we are in the transfer phase now
						Parameter.with("upload_phase", "transfer"),
						// The offset the file chunk starts
						Parameter.with("start_offset", startOffset),
						// The important session ID of this file transfer
						Parameter.with("upload_session_id", uploadSessionId));
				// After uploading the chunk we recalculate the offsets
				// according to the
				// information provided by Facebook
				LOGGER.info("视频片段【" + (index++) + "】上传完毕： " + "startOffset = " + startOffset + ", endOffset = "
						+ endOffset);
				startOffset = filePart.getStartOffset();
				endOffset = filePart.getEndOffset();
				length = (int) (endOffset - startOffset);
			}
		} catch (Exception e) {
			LOGGER.error(
					"视频片段【" + (index++) + "】上传失败： " + "startOffset = " + startOffset + ", endOffset = " + endOffset);
			e.printStackTrace();
		} finally {
			if (null != in) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private String finalizeVideo(String uploadSessionId, String content) {
		GraphResponse finishResponse = facebookClient.publish(accountId + "/videos", GraphResponse.class,
				Parameter.with("description", content), Parameter.with("upload_phase", "finish"),
				Parameter.with("upload_session_id", uploadSessionId));
		LOGGER.info("视频上传完毕： id = " + finishResponse.getId() + " postId = " + finishResponse.getPostId()
				+ " timeline = " + finishResponse.getTimelineId());
		return finishResponse.getId();
	}

	private ResumableUploadStartResponse initVideo(File videoFile) {
		try {
			long filesizeInBytes = videoFile.length();
			return facebookClient.publish(accountId + "/videos", ResumableUploadStartResponse.class, // The
					Parameter.with("upload_phase", "start"), // The upload phase
					Parameter.with("file_size", filesizeInBytes)); // The file
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean publish(PublishTaskVo vo) throws Exception {
		init(vo.getUsername(), vo.getPassword());
		String content = vo.getContent();
		File videoFile = vo.getVideoFile();
		String postId = "";
		List<File> imageFileList = vo.getImageFileList();
		if (StringUtils.isNotEmpty(vo.getPageId())){
			postId = updateMessage(vo.getPageId(), content);
		}
		else if (null != videoFile && videoFile.exists()) {
			postId = uploadVideo(videoFile,content);
		} else if (!imageFileList.isEmpty()) {
			List<File> fileList = new ArrayList<File>();
			for (File file : imageFileList) {
				if (file.exists()) {
					fileList.add(file);
				}else {
					LOGGER.error("文件不存在: file = " + file.getAbsolutePath());
					return false;
				}
			}
			postId = publishPhotos(content, fileList);
		} else {
			postId = publishMessage(content);
		}
		LOGGER.info("发帖Id = " + postId);
		vo.setPageId(postId);
		return true;
	}

	@Override
	public String getPublishType() {
		return Constants.FACEBOOK;
	}
	
	 public static void main(String[] args) {
		 Facebook3 face = new Facebook3();
		 face.init("8860975141599", "sun0522");
		 File f1 = new File("C:\\Users\\yl\\Pictures\\VID_20180130_172158.mp4");
		 File f2 = new File("C:\\Users\\yl\\Pictures\\VID_20180130_172141.mp4");
		  f1 = new File("C:\\Users\\yl\\Pictures\\5dbeb36a70984c248b998a6861740e9c.jpg");
		  f2 = new File("C:\\Users\\yl\\Pictures\\abc.jpg");
		 
		 List<File> fileList = new ArrayList<File>();
		 fileList.add(f2);
		 fileList.add(f1);
		 try {
			 face.publishPhotos("多图ABCDA测试", fileList);
			//face.updateMessage("154206585196477_171475543469581", "zwtest改为旧数据");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
}
