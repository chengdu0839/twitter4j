package com.sobey.publish.common;

import java.util.Collections;
import java.util.concurrent.DelayQueue;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.sobey.publish.util.PluginExtendUtils;

@Component
public class TokenService {
	private static Logger LOGGER = Logger.getLogger(TokenService.class);
	/**
	 * 账号信息缓存
	 */
	private DelayQueue<TokenInfo> delayQueue = new DelayQueue<TokenInfo>();

	public void putQueue(TokenInfo info) {
		delayQueue.put(info);
	}

	public TokenInfo getToken(String type, String username, String password) {
		TokenInfo[] arrayInfos = delayQueue.toArray(new TokenInfo[] {});
		if (null != arrayInfos) {
			for (TokenInfo info : arrayInfos) {
				if (username.equals(info.getUsername()) && password.equals(info.getPassword())
						&& type.equals(info.getType())) {
					return info;
				}
			}
		}
		return null;
	}

	@Async("overseaExecutor")
	public void initTokenRunner() {
		Collections.<Class<? extends Throwable>, Boolean> singletonMap(Exception.class, true);
		while (true) {
			try {
				TokenInfo info = delayQueue.take();
				LOGGER.info("Runner获取token" + info.toString());
				IPublishService service = PluginExtendUtils.getIPublishService(info.getType());
				TokenInfo tokenInfo = service.getToken(info.getUsername(), info.getPassword());
				LOGGER.info("获取token = " + tokenInfo.toString());
				if (null != tokenInfo) {
					delayQueue.put(tokenInfo);
				}
			} catch (InterruptedException e) {
				LOGGER.error("Runner获取缓存数据失败", e);
			}
		}

	}
}
