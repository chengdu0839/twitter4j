package com.sobey.publish.common;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 发布任务对象
 * 
 * @ClassName: PublishTaskVo
 * @Description: TODO
 * @author shijiyu
 * @date 2014-11-25 上午11:11:13
 * 
 */
@SuppressWarnings("serial")
public class PublishTaskVo implements Serializable {

	private int id;// 对应数据库表taskview的主键ID
	
	private File videoFile;
	
	private String title;
	
	private String content;
	
	private String keyword;
	
	/**
	 * 发布任务标题
	 * 
	 * @Fields the tasktitle type is String: TODO
	 */
	private String tasktitle;
	/**
	 * 发布渠道
	 * 
	 * @Fields the publishtype type is String: TODO
	 */
	private String publishtype;

	/**
	 * 发布渠道名称
	 * 
	 * @Fields the publishname type is String: TODO
	 */
	private String publishname;
	/**
	 * 发布状态，0 解析完进入数据库，-1失败 1处理中 2处理完成
	 * 
	 * @Fields the status type is int: TODO
	 */
	private int status;
	/**
	 * 发布开始时间
	 * 
	 * @Fields the starttime type is int: TODO
	 */
	private long starttime;
	/**
	 * 结束时间
	 * 
	 * @Fields the endtime type is int: TODO
	 */
	private long endtime;
	/**
	 * 发布元数据
	 * 
	 * @Fields the metadata type is String: TODO
	 */
	private Object metadata;

	/**
	 * 描述
	 * 
	 * @Fields the description type is String: TODO
	 */
	private String description;

	/**
	 * 对应实际发布任务的信息的主键值,有可能需要回调信息
	 * 
	 * @Fields the taskuuid type is String: TODO
	 */
	private String taskuuid;
	
	private String username;
	
	private String password;
	
	private List<File> imageFileList = new ArrayList<File>();
	
	private String pageId;

	public String getTasktitle() {
		return tasktitle;
	}

	public String getPublishtype() {
		return publishtype;
	}

	public int getStatus() {
		return status;
	}

	public long getStarttime() {
		return starttime;
	}

	public long getEndtime() {
		return endtime;
	}

	public Object getMetadata() {
		return metadata;
	}

	public String getDescription() {
		return description;
	}

	public void setTasktitle(String tasktitle) {
		this.tasktitle = tasktitle;
	}

	public void setPublishtype(String publishtype) {
		this.publishtype = publishtype;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void setStarttime(long starttime) {
		this.starttime = starttime;
	}

	public void setEndtime(long endtime) {
		this.endtime = endtime;
	}

	public void setMetadata(Object metadata) {
		this.metadata = metadata;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTaskuuid() {
		return taskuuid;
	}

	public void setTaskuuid(String taskuuid) {
		this.taskuuid = taskuuid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPublishname() {
		return publishname;
	}

	public void setPublishname(String publishname) {
		this.publishname = publishname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public File getVideoFile() {
		return videoFile;
	}

	public void setVideoFile(File videoFile) {
		this.videoFile = videoFile;
	}

	public List<File> getImageFileList() {
		return imageFileList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
}
