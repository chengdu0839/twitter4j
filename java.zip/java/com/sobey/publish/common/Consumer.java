package com.sobey.publish.common;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.jms.Destination;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sobey.publish.util.PluginExtendUtils;

@Component
public class Consumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(Consumer.class);

	@Value("${back.destination}")
	private String backDestination;

	@Value("${ftp.path}")
	private String ftpPath;

	@Autowired
	private Producer producer;

	// 使用JmsListener配置消费者监听的队列，其中text是接收到的消息
	@JmsListener(destination = "${queue.destination}", containerFactory = "defaultJmsListenerContainerFactory")
	public void receiveQueue(String text) {
		LOGGER.info("接收到的MQ内容为:" + text);
		new Thread(new Runnable() {
			@Override
			public void run() {
				JSONObject param = new JSONObject();
				param.put("status", false);
				try {
					JSONObject inputObj = JSON.parseObject(text);
					param.put("taskid", inputObj.getString("taskid"));
					param.put("postId", "");
					PublishTaskVo vo = parser(inputObj);
					String channelcode = inputObj.getString("channelcode");
					IPublishService publishService = PluginExtendUtils.getIPublishService(channelcode);
					if (null != publishService){
						boolean publish = publishService.publish(vo);
						param.put("status", publish);
						param.put("message", "");
						if (StringUtils.isNotEmpty(vo.getPageId())){
							param.put("postId", vo.getPageId());
						}
					}
					else{
						param.put("message", "未找到发布类型为:【"+channelcode+"】的实现，请联系管理员");
					}
				} catch (Exception e) {
					param.put("message", e.getMessage());
				}
				LOGGER.info("MQ反馈信息： " + param.toString());
				Destination destination = new ActiveMQQueue(backDestination);
				producer.sendMessage(destination, param.toString());
			}
		}).start();
	}

	private PublishTaskVo parser(JSONObject inputObj) {
		JSONObject accountsObject = inputObj.getJSONObject("accounts");
		String username = accountsObject.getString("username");
		String password = accountsObject.getString("password");
		JSONObject contentObject = inputObj.getJSONObject("content");
		PublishTaskVo taskVo = new PublishTaskVo();
		String content = contentObject.getString("content");
		String pathDir = inputObj.getString("path");
		String title = contentObject.getString("title");
		String keyword = contentObject.getString("keyword");
		String postId = inputObj.getString("postId");
		taskVo.setUsername(username);
		taskVo.setPassword(password);
		taskVo.setTitle(title);
		taskVo.setPageId(postId);
		taskVo.setContent(content);
		taskVo.setKeyword(keyword);
		String videoUrl = inputObj.getString("videoPath");
		if (StringUtils.isNotEmpty(videoUrl)) {
			videoUrl = ftpPath + pathDir + videoUrl.substring(videoUrl.lastIndexOf("/") + 1);
			File videoFile = new File(videoUrl);
			if (videoFile.exists()) {
				taskVo.setVideoFile(videoFile);
			}
		}
		JSONArray imageArray = inputObj.getJSONArray("imagePath");
		if (null != imageArray && !imageArray.isEmpty()) {
			for (int i = 0; i < imageArray.size(); i++) {
				String image = imageArray.getString(i);
			//	String imageUrl = (String) ((Map<?, ?>) imageArray.get(i)).get("image");
			//String imagePath = ftpPath + pathDir + imageUrl.substring(imageUrl.lastIndexOf("/") + 1);
				String imagePath = ftpPath + pathDir + image;
				File imageFile = new File(imagePath);
				if (imageFile.exists()) {
					taskVo.getImageFileList().add(imageFile);
				}
			}
		}
		return taskVo;
	}
	
	private static void downFile(){}
	
	public static void main(String[] args) {
		downFile();
	}
}
