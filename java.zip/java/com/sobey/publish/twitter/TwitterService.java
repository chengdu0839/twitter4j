package com.sobey.publish.twitter;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sobey.publish.common.Constants;
import com.sobey.publish.common.IPublishService;
import com.sobey.publish.common.PublishTaskVo;
import com.sobey.publish.common.TokenInfo;
import com.sobey.publish.twitter.client.ClientService;
import com.sobey.publish.twitter.client.ClientServiceImpl;
import com.sobey.publish.util.HttpClientUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.StreamDataBodyPart;

import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.UploadedMedia;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

@Component
public class TwitterService implements IPublishService {
	private Logger logger = Logger.getLogger(TwitterService.class);
	@Value("${twitter.clientId}")
	private String authConsumerKey;
	@Value("${twitter.clientSecret}")
	private String authConsumerSecret;
	@Value("${twitter.redirectUri}")
	private String redirectUri;
	private String RESOURCE = "/1.1/media/upload.json";
	private WebResource webResource = null;
	private Twitter twitter;
	private Client client = null;

	private void init(String username, String password) {
		try {
			ConfigurationBuilder builder = new ConfigurationBuilder();
			builder.setOAuthConsumerKey(authConsumerKey);
			builder.setOAuthConsumerSecret(authConsumerSecret);
			Configuration configuration = builder.build();
			TwitterFactory factory = new TwitterFactory(configuration);
			twitter = factory.getInstance();
			RequestToken requestToken = twitter.getOAuthRequestToken();
			String url = "http://localhost:9294/getToken?redirect_uri=" + redirectUri + "&client_id="
					+ requestToken.getToken() + "&client_secret=KOa&usercode=" + username + "&password=" + password;
			logger.info("获取Twitter的url地址为: " + url);
			String result = HttpClientUtil.getInstance().get(url);
			logger.info("获取用户token返回值:" + result);
			JSONObject jsonObject = JSON.parseObject(result);
			if (jsonObject.containsKey("code") && jsonObject.containsKey("authorcode")
					&& jsonObject.getString("code").equals("200")) {
				String authorcode = jsonObject.getString("authorcode");
				AccessToken oAuthAccessToken = twitter.getOAuthAccessToken(requestToken, authorcode);
				ClientService clientService = new ClientServiceImpl(authConsumerKey, authConsumerSecret,
						oAuthAccessToken.getToken(), oAuthAccessToken.getTokenSecret());
				client = clientService.getClient();
			} else {
				throw new RuntimeException("获取token异常" + result);
			}
		} catch (TwitterException e) {
			throw new RuntimeException("获取Twitter的token异常:", e);
		}
	}

	public long getImageId(String fileName, InputStream media) throws TwitterException {
		logger.info("上传Twitter图片fileName = " + fileName);
		UploadedMedia uploadMedia = twitter.uploadMedia(fileName, media);
		return uploadMedia.getMediaId();
	}

	public Status uploadImageStatus(String text, long[] mediaIds) throws TwitterException {
		logger.info("上传Twitter图文 text = " + text + ", mediaIds = " + mediaIds);
		StatusUpdate status = new StatusUpdate(text);
		status.setMediaIds(mediaIds);
		return twitter.updateStatus(status);
	}

	private void appendVideo(File file, String mediaId) {
		FileInputStream fis = null;
		try {
			int index = 0;
			fis = new FileInputStream(file);
			int byteSize = 4 * 1024 * 1024;
			byte[] b = new byte[byteSize];
			int available = 0;
			while ((available = fis.available()) > 0) {
				if (available < (byteSize)) {
					b = new byte[available];
				}
				fis.read(b);
				logger.info(
						"Twitter视频片段上传: segment_index = " + index + ", mediaId = " + mediaId + ", size = " + b.length);
				FormDataMultiPart form = new FormDataMultiPart();
				form.field("command", "APPEND");
				form.field("media_id", mediaId);
				form.field("segment_index", String.valueOf(index));
				ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(b);
				StreamDataBodyPart stream = new StreamDataBodyPart("media", byteArrayInputStream);
				final FormDataMultiPart multiPartForm = (FormDataMultiPart) form.bodyPart(stream);
				ClientResponse response = webResource.path(RESOURCE).type(MediaType.MULTIPART_FORM_DATA_TYPE)
						.accept(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class, multiPartForm);
				form.close();
				byteArrayInputStream.close();
				int status = response.getStatus();
				logger.info("Twitter视频文件片段上传结束 status = " + status);
				++index;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private String finalizeVideo(String mediaId) {
		MultivaluedMap<String, String> finalizeParams = new MultivaluedMapImpl();
		finalizeParams.add("command", "FINALIZE");
		finalizeParams.add("media_id", mediaId);
		ClientResponse response = webResource.path(RESOURCE).type(MediaType.APPLICATION_FORM_URLENCODED)
				.accept(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class, finalizeParams);
		int status = response.getStatus();
		String output = response.getEntity(String.class);
		logger.info("上传视频结束返回信息： " + output);
		if (status != 200 && status != 201) {
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
		}
		JsonObject jsonObj = new JsonParser().parse(output).getAsJsonObject();
		return jsonObj.get("processing_info").toString();
	}

	private String initVideo(File file) {
		MultivaluedMap<String, String> params = new MultivaluedMapImpl();
		params.add("command", "INIT");
		params.add("media_type", "video/mp4");
		params.add("media_category", "tweet_video");
		String totalBytes = Long.toString(file.length());
		logger.info("初始化Twitter视频文件: file = " + file.getAbsolutePath() + ", size = " + totalBytes);
		params.add("total_bytes", totalBytes);
		ClientResponse response = webResource.path(RESOURCE).type(MediaType.APPLICATION_FORM_URLENCODED)
				.accept(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class, params);
		int status = response.getStatus();
		String output = response.getEntity(String.class);
		logger.info("初始化Twitter视频信息返回信息: output = " + output);
		if (status != 202 && status != 200) {
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
		}
		JsonObject jsonObj = new JsonParser().parse(output).getAsJsonObject();
		return jsonObj.get("media_id_string").getAsString();
	}

	/**
	 * Twitter视频上传。最多支持2分20秒
	 * @param file
	 *            视频文件
	 * @param content
	 *            Twitter文字内容
	 * @throws TwitterException
	 */
	public void uploadVideo(File file, String content) throws TwitterException {
		webResource = client.resource(Constants.TWITTER_UPLOAD);
		String mediaId = initVideo(file);
		appendVideo(file, mediaId);
		String info = finalizeVideo(mediaId);
		String errMsg = checkVideoStatus(info, mediaId);
		if (StringUtils.isEmpty(errMsg)) {
			logger.info("Twitter视频发布：status = " + content + ",mediaId： " + mediaId);
			long[] m = new long[1];
			m[0] = Long.parseLong(mediaId);
			Status status = uploadImageStatus(content, m);
			logger.info("包含视频的Twitter上传成功： " + status.getId());
		} else {
			throw new RuntimeException("Twitter视频不合法 : mediaId = " + mediaId + ", error = " + errMsg);
		}
	}

	/**
	 * 发送Twitter文本。话题以#开始，空格结束。比如：话题 #ManhattanAttack 测试
	 * @param text
	 * @return
	 * @throws TwitterException
	 */
	public Status uploadStatus(String text) throws TwitterException {
		logger.info("文本Twitter上传: text = " + text);
		return twitter.updateStatus(text);
	}

	private String checkVideoStatus(String info, String mediaId) {
		JsonObject jsonObj = new JsonParser().parse(info).getAsJsonObject();
		String state = jsonObj.get("state").getAsString();
		if ("succeeded".equals(state)) {
			return "";
		} else if ("failed".equals(state)) {
			return info;
		}
		String check_after_secs = jsonObj.get("check_after_secs").getAsString();
		try {
			Thread.sleep(Integer.parseInt(check_after_secs) * 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
		queryParams.add("command", "STATUS");
		queryParams.add("media_id", mediaId);
		ClientResponse response = webResource.path(RESOURCE).queryParams(queryParams)
				.accept(MediaType.APPLICATION_JSON_TYPE).get(ClientResponse.class);
		int status = response.getStatus();
		String output = response.getEntity(String.class);
		logger.info("上传视频结束返回信息： " + output);
		if (status != 200 && status != 201) {
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
		}
		jsonObj = new JsonParser().parse(output).getAsJsonObject();
		info = jsonObj.get("processing_info").toString();
		return checkVideoStatus(info, mediaId);
	}
	
	@Override
	public boolean publish(PublishTaskVo vo) throws Exception {
		try {
			init(vo.getUsername(), vo.getPassword());
			String content = vo.getContent();
			File videoFile = vo.getVideoFile();
			List<File> imageFileList = vo.getImageFileList();
			if (null != videoFile) {
				uploadVideo(vo.getVideoFile(), vo.getContent());
			} else if (!imageFileList.isEmpty()) {
				List<Long> mediaIdList = new ArrayList<Long>();
				int size = imageFileList.size();
				for (int i = 0; i < size; i++) {
					File imageFile = imageFileList.get(i);
					long mediaId = getImageId(imageFile.getName(), new FileInputStream(imageFile));
					mediaIdList.add(mediaId);
					if (mediaIdList.size() > 3) {
						logger.info("图片数量大于4张，只上传前4张图片！");
						break;
					}
				}
				long[] mediaIds = new long[mediaIdList.size()];
				for (int i = 0; i < mediaIdList.size(); i++) {
					mediaIds[i] = mediaIdList.get(i);
				}
				uploadImageStatus(content, mediaIds);
			} else {
				uploadStatus(content);
			}
		} catch (TwitterException e) {
			logger.error(e);
			throw new RuntimeException(e.getErrorMessage());
		}
		return true;
	}

	@Override
	public String getPublishType() {
		return Constants.TWITTER;
	}

	@Override
	public TokenInfo getToken(String username, String password) {
		return null;
	}
}
