/*
 * Copyright (c) 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package com.sobey.publish.youtube;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.http.InputStreamContent;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.YouTube.Thumbnails.Set;
import com.google.api.services.youtube.model.ThumbnailSetResponse;
import com.google.api.services.youtube.model.Video;
import com.google.api.services.youtube.model.VideoSnippet;
import com.google.api.services.youtube.model.VideoStatus;

/**
 * Upload a video to the authenticated user's channel. Use OAuth 2.0 to
 * authorize the request. Note that you must add your video files to the project
 * folder to upload them with this application.
 *
 * @author Jeremy Walker
 */
public class UploadVideo {
	private static Logger LOGGER = Logger.getLogger(UploadVideo.class);
	/**
	 * Define a global instance of a Youtube object, which will be used to make
	 * YouTube Data API requests.
	 */
	private YouTube youtube;
	
	private Credential credential;

	/**
	 * Define a global variable that specifies the MIME type of the video being
	 * uploaded.
	 */
	private static final String VIDEO_FILE_FORMAT = "video/*";
	
	public UploadVideo(Credential credential){
		this.credential = credential;
	}

	public Video upload(final String title, String message, String keyword, final File file, File imgFile) {

		try {
			 LOGGER.info("facebook：size = " + file.length() + ", name = " + file.getName());
			// Authorize the request.
			//credential = Auth.authorize(null, null);
			// This object is used to make YouTube Data API requests.
			youtube = new YouTube.Builder(Auth.HTTP_TRANSPORT, Auth.JSON_FACTORY, credential).build();

			// Add extra information to the video before uploading.
			Video videoObjectDefiningMetadata = new Video();

			// Set the video to be publicly visible. This is the default
			// setting. Other supporting settings are "unlisted" and "private."
			VideoStatus status = new VideoStatus();
			status.setPrivacyStatus("public");
			videoObjectDefiningMetadata.setStatus(status);

			VideoSnippet snippet = new VideoSnippet();
			snippet.setTitle(title);
			snippet.setDescription(message);
			if (!StringUtils.isEmpty(keyword)){
				List<String> tags = new ArrayList<String>();
				String[] keywords = keyword.split("\\s+");
				for (String word : keywords) {
					if (!StringUtils.isEmpty(word)) {
						tags.add(word);
					}
				}
				// Set the keyword tags that you want to associate with the video.
				snippet.setTags(tags);
			}

			// Add the completed snippet object to the video resource.
			videoObjectDefiningMetadata.setSnippet(snippet);
			InputStreamContent mediaContent = new InputStreamContent(VIDEO_FILE_FORMAT, new FileInputStream(file));
			// Insert the video. The command sends three arguments. The first
			// specifies which information the API request is setting and which
			// information the API response should return. The second argument
			// is the video resource that contains metadata about the new video.
			// The third argument is the actual video content.
			YouTube.Videos.Insert videoInsert = youtube.videos().insert("snippet,statistics,status",
					videoObjectDefiningMetadata, mediaContent);
			// Set the upload type and add an event listener.
			MediaHttpUploader uploader = videoInsert.getMediaHttpUploader();
			// Indicate whether direct media upload is enabled. A value of
			// "True" indicates that direct media upload is enabled and that
			// the entire media content will be uploaded in a single request.
			// A value of "False," which is the default, indicates that the
			// request will use the resumable media upload protocol, which
			// supports the ability to resume an upload operation after a
			// network interruption or other transmission failure, saving
			// time and bandwidth in the event of network failures.
			uploader.setDirectUploadEnabled(false);
			MediaHttpUploaderProgressListener progressListener = new MediaHttpUploaderProgressListener() {
				public void progressChanged(MediaHttpUploader uploader) throws IOException {
					switch (uploader.getUploadState()) {
					case INITIATION_STARTED:
						LOGGER.info("Initiation Started：title = " + title + ", name = " + file.getName());
						break;
					case INITIATION_COMPLETE:
						LOGGER.info("Initiation Completed：title = " + title + ", name = " + file.getName());
						break;
					case MEDIA_IN_PROGRESS:
						LOGGER.info("Upload percentage: " + uploader.getNumBytesUploaded() + ", title = " + title
								+ ", name = " + file.getName());
						break;
					case MEDIA_COMPLETE:
						LOGGER.info("Upload Completed：title = " + title + ", name = " + file.getName());
						break;
					case NOT_STARTED:
						LOGGER.info("Upload Not Started：title = " + title + ", name = " + file.getName());
						break;
					default:
						LOGGER.info("youtube视频上传异常：title = " + title + ", name = " + file.getName());
						break;
					}
				}
			};
			uploader.setProgressListener(progressListener);
			Video execute = videoInsert.execute();
			if (null != imgFile && imgFile.exists()) {
				uploadThumbnail(execute.getId(), imgFile);
			}
			return execute;
		} catch (IOException e) {
			LOGGER.error("youtube上传失败：" + e.getMessage(), e);
			throw new RuntimeException("youtube上传失败:" + e.getMessage());
		}
	}

	private void uploadThumbnail(String videoId, final File imageFile) {
		try {
			InputStreamContent mediaContent = new InputStreamContent("image/png",
					new BufferedInputStream(new FileInputStream(imageFile)));
			mediaContent.setLength(imageFile.length());
			Set thumbnailSet = youtube.thumbnails().set(videoId, mediaContent);

			MediaHttpUploader uploader = thumbnailSet.getMediaHttpUploader();
			uploader.setDirectUploadEnabled(false);
			MediaHttpUploaderProgressListener progressListener = new MediaHttpUploaderProgressListener() {
				@Override
				public void progressChanged(MediaHttpUploader uploader) throws IOException {
					switch (uploader.getUploadState()) {
					// This value is set before the initiation request is
					// sent.
					case INITIATION_STARTED:
						LOGGER.info("Initiation Started：file = " + imageFile.getAbsolutePath());
						break;
					// This value is set after the initiation request
					// completes.
					case INITIATION_COMPLETE:
						LOGGER.info("Initiation Completed：file = " + imageFile.getAbsolutePath());
						break;
					// This value is set after a media file chunk is
					// uploaded.
					case MEDIA_IN_PROGRESS:
						break;
					// This value is set after the entire media file has
					// been successfully uploaded.
					case MEDIA_COMPLETE:
						LOGGER.info("Upload Completed：file = " + imageFile.getAbsolutePath());
						break;
					// This value indicates that the upload process has
					// not started yet.
					case NOT_STARTED:
						LOGGER.info("Upload Not Started：file = " + imageFile.getAbsolutePath());
						break;
					}
				}
			};
			uploader.setProgressListener(progressListener);
			ThumbnailSetResponse setResponse = thumbnailSet.execute();
			LOGGER.info("Uploaded Thumbnail：file = " + setResponse.getItems().get(0).getDefault().getUrl());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
