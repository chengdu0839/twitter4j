package com.sobey.publish.youtube;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.api.client.auth.oauth2.Credential;
import com.sobey.publish.common.Constants;
import com.sobey.publish.common.IPublishService;
import com.sobey.publish.common.PublishTaskVo;
import com.sobey.publish.common.TokenInfo;

@Component
public class YouTubeService implements IPublishService {
	private static Logger logger = Logger.getLogger(YouTubeService.class);
	private Credential credential;
	@Autowired
	private Auth auth;

	@Override
	public boolean publish(PublishTaskVo vo) throws Exception {
		try {
			credential = auth.authorize(vo.getUsername(), vo.getPassword());
			UploadVideo video = new UploadVideo(credential);
			File imgFile = null;
			List<File> imageFileList = vo.getImageFileList();
			if (!imageFileList.isEmpty()) {
				imgFile = imageFileList.get(0);
			}
			video.upload(vo.getTitle(), vo.getContent(), vo.getKeyword(), vo.getVideoFile(), imgFile);
		} catch (IOException e) {
			logger.error("token获取失败：" + e.getMessage(), e);
			throw new RuntimeException("token获取失败:" + e.getMessage());
		}
		return true;
	}

	@Override
	public String getPublishType() {
		return Constants.YOUTUBE;
	}

	@Override
	public TokenInfo getToken(String username, String password) {
		return null;
	}
}
