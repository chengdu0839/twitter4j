package com.sobey.publish.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sobey.publish.common.IPublishService;

/**
 * 获取可用的发布渠道工具类
 * @author Administrator
 */
public class PluginExtendUtils {
    private static Logger logger = Logger.getLogger(PluginExtendUtils.class);

	private static Map<String, IPublishService> publishMap = new HashMap<String, IPublishService>();

	public static synchronized IPublishService getIPublishService(String publishtype) {
		if (publishMap.isEmpty()) {
			Map<String, IPublishService> result = ApplicationUtil.getApplicationContext().getBeansOfType(IPublishService.class);
			Collection<IPublishService> values = result.values();
			for (IPublishService publishServive : values){
				String channelType = publishServive.getPublishType();
				publishMap.put(channelType, publishServive);
			}
		}
		IPublishService service =  publishMap.get(publishtype);
		if(service==null){
			logger.error("未找到发布类型为:【"+publishtype+"】的实现，请联系管理员");
		}
		return service;
	}
}
