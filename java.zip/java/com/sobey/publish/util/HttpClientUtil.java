package com.sobey.publish.util;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HttpClientUtil {
	private Logger logger = Logger.getLogger(HttpClientUtil.class);

	private static class InstanceHolder {
		private static HttpClientUtil instance = new HttpClientUtil();
	}

	public static HttpClientUtil getInstance() {
		return InstanceHolder.instance;
	}

	/**
	 * 
	 * @Title: postJson
	 * @Description: TODO
	 * @param url
	 * @param jsonParam
	 */
	public String postJson(String url, String jsonParam, String charset) throws IOException {
		logger.info("接口地址" + url + ",参数：" + jsonParam);
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String result = "";
		HttpPost method = new HttpPost(url);
		try {
			if (null != jsonParam) {
				StringEntity entity = new StringEntity(jsonParam, charset);
				entity.setContentEncoding(charset);
				entity.setContentType("application/json");
				method.setEntity(entity);
			}
			CloseableHttpResponse response = httpclient.execute(method);
			if (response != null) {
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					result = EntityUtils.toString(resEntity, charset);
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw new IOException(e);
		} finally {
			method.releaseConnection();
		}
		logger.info("接口返回结果：" + result);
		return result;
	}

	/**
	 * 
	 * @Title: postMap
	 * @Description: TODO
	 * @param url
	 * @param map
	 * @param charset
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String postMap(String url, Map<String, String> map, String charset) throws IOException {
		logger.info("接口地址" + url + ",参数：" + map);
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = null;
		try {
			httpPost = new HttpPost(url);
			List<NameValuePair> list = new ArrayList<NameValuePair>();
			Iterator iterator = map.entrySet().iterator();
			while (iterator.hasNext()) {
				Entry<String, String> elem = (Entry<String, String>) iterator.next();
				list.add(new BasicNameValuePair(elem.getKey(), elem.getValue()));
			}
			if (list.size() > 0) {
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list, charset);
				httpPost.setEntity(entity);
			}
			CloseableHttpResponse response = httpclient.execute(httpPost);
			if (response != null) {
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					return EntityUtils.toString(resEntity, charset);
				}
			}
			throw new RuntimeException("请求返回状态不为成功状态:"+response.getStatusLine().getStatusCode());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new IOException(e);
		} finally {
			if (null != httpPost) {
				httpPost.releaseConnection();
			}
		}
	}

	public String postUpload(String url, Map<String, String> map,Map<String,File> fileMap) {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);
		try {
			
			MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
			for(Map.Entry<String, String> entry:map.entrySet())
				multipartEntityBuilder.addTextBody(entry.getKey(), URLEncoder.encode(entry.getValue(),"UTF-8"));
			for(Map.Entry<String, File> entry:fileMap.entrySet())
				multipartEntityBuilder.addBinaryBody(entry.getKey(), entry.getValue(),ContentType.MULTIPART_FORM_DATA,entry.getValue().getName());
			httpPost.setEntity(multipartEntityBuilder.build());
			CloseableHttpResponse response = httpclient.execute(httpPost);
			if (response != null) {
				HttpEntity resEntity = response.getEntity();
				if (resEntity != null) {
					return EntityUtils.toString(resEntity, "UTF-8");
				}
			}
			throw new RuntimeException("请求返回状态不为成功状态:"+response.getStatusLine().getStatusCode());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			if (null != httpPost) {
				httpPost.releaseConnection();
			}
		}
	}

	public String get(String url) {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(url);
		try {  
			RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(10000)
					.setConnectionRequestTimeout(10000).setSocketTimeout(10000).build();
			httpGet.setConfig(requestConfig);
			CloseableHttpResponse response = httpclient.execute(httpGet);
			int statuCode = response.getStatusLine().getStatusCode();
			if (statuCode == HttpStatus.SC_OK) {
				return EntityUtils.toString(response.getEntity(), "UTF-8");
			}
			logger.info("请求地址" + url + "返回状态为：" + statuCode);
			throw new RuntimeException("请求地址" + url + "返回状态为：" + statuCode);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			httpGet.releaseConnection();
		}
	}
}
